# Font licences

The fonts in this directory and where they come from. Every one allows
redistribution; the notes say what else each asks for.

| Family | Files | Source | Licence |
|---|---|---|---|
| Seven Segment | seg7* | DSEG7 Classic (c) 2017 keshikan, rasterised by tools/ttf-to-bdf.py | SIL Open Font License 1.1 (tools/fonts-src/dseg7/OFL.txt); renamed because "DSEG" is a Reserved Font Name |
| Roboto | roboto-*, robotob-* | Roboto (c) 2011 The Roboto Project Authors, from google/fonts, rasterised at 4 bits by tools/ttf-to-bdf.py | SIL Open Font License 1.1 (tools/fonts-src/roboto/OFL.txt) |
| Roboto Condensed | robotocond-*, robotocondb-* | Roboto Condensed (c) 2011 The Roboto Project Authors, from google/fonts, rasterised at 4 bits | SIL Open Font License 1.1 (tools/fonts-src/roboto-condensed/OFL.txt) |
| Inter | inter-*, interb-* | Inter (c) 2020 The Inter Project Authors, from google/fonts, rasterised at 4 bits | SIL Open Font License 1.1 (tools/fonts-src/inter/OFL.txt) |
| Montserrat | montserrat-*, montserratb-* | Montserrat (c) 2024 The Montserrat.Git Project Authors, from google/fonts, rasterised at 4 bits | SIL Open Font License 1.1 (tools/fonts-src/montserrat/OFL.txt) |
