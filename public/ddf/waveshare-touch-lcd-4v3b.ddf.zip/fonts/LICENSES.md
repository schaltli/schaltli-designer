# Font licences

The fonts in this directory and where they come from. Every one allows
redistribution; the notes say what else each asks for.

| Family | Files | Source | Licence |
|---|---|---|---|
| Helvetica | helvR*, helvB* | X11 via u8g2 (Adobe, Digital Equipment Corporation) | Permission to use, copy, modify, distribute and sell, provided the copyright notices appear in all copies |
| Courier | courR* | X11 via u8g2 (Adobe, DEC) | as Helvetica |
| Lucida Sans | luRS*, luBS* | X11 via u8g2, (c) Bigelow & Holmes 1985, 1986 | Free to use and redistribute; "Lucida" is a trademark of Bigelow & Holmes and may be used only for the unmodified bitmaps, which these are |
| FreeUniversal | fur*, fub* | u8g2, (c) Stephen Wilson 2009, from SIL Sophia (c) SIL International 1994-2008 | SIL Open Font License 1.1 |
| Logisoso | logisoso* | u8g2, (c) Mathieu Gabiot 2009, 2011 | GPL v2 with font exception, also SIL OFL |
| LogiSoSo digits | logisoso62n | as Logisoso | as Logisoso |
| Seven Segment | seg7* | DSEG7 Classic (c) 2017 keshikan, rasterised by tools/ttf-to-bdf.py | SIL Open Font License 1.1 (tools/fonts-src/dseg7/OFL.txt); renamed because "DSEG" is a Reserved Font Name |

u8g2's font list with each group's licence: https://github.com/olikraus/u8g2/wiki/fntgrp
